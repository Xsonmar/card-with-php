<?php
//الاتصال بقاعده البيانات
	function db_connect(){//اسم الفنكشن الي بنخزن فيها الاتصال بقاعده البيانات
		$conn = mysqli_connect("localhost", "root", "", "obs_db");//obs_db اسم الداتا بيز هو 
		if(!$conn){
			echo "Can't connect database " . mysqli_connect_error($conn);
			exit;
		}
		return $conn;
	}

	//فنكشن لديها وظيفه اظهار اخر اربع اضافات حديثه في قاعده البيانات
	function select4LatestBook($conn){ //$connالمتصله بقاعده البيانات في متغير  select4LatestBookفنكشن  اسمها 
		$row = array();//في مصفوفه
		$query = "SELECT book_isbn, book_image, book_title FROM books ORDER BY abs(unix_timestamp(created_at)) DESC";//استعلم عن بيانات مرتبه ترتيب تصاعدي من جدول الكتب
		$result = mysqli_query($conn, $query);//$result تخزينها في متغير 
		if(!$result){//اذا كان الاستعلام خطأ
		    echo "Can't retrieve data " . mysqli_error($conn);//اطبع رساله الخطاء التاليه
		    exit;//خروج
		}
		for($i = 0; $i < 4; $i++){//في فور لوب بعدد اربع
			array_push($row, mysqli_fetch_assoc($result));//خذ البيانات في مصفوفه عددها اربع بواسطه الفور لوب
		}
		return $row;//ارجاع المتغير
	}

	function getBookByIsbn($conn, $isbn){
		$query = "SELECT book_title, book_author, book_price FROM books WHERE book_isbn = '$isbn'";
		$result = mysqli_query($conn, $query);
		if(!$result){
			echo "Can't retrieve data " . mysqli_error($conn);
			exit;
		}
		return $result;//ارجاع المتغير
	}



	
//فنكشن سعر الكتاب و الاسبن
	function getbookprice($isbn){
		$conn = db_connect(); //الاتصال بقاعده البيانات
		$query = "SELECT book_price FROM books WHERE book_isbn = '$isbn'";//الاستعلام
		$result = mysqli_query($conn, $query);//تخزين الاستعلام في متغير
		if(!$result){//ان كان تخزين الاستعلام خطأ
			echo "get book price failed! " . mysqli_error($conn);//اطبع رساله خطاء
			exit;//خروج
		}
		$row = mysqli_fetch_assoc($result);//طباعه الاستعلام في مصفوفه
		return $row['book_price'];//ارجاع البيانات من مصفوفه في متغير
	}


	//جلب بيانات الكتب في فنكشن 
	function getPubName($conn, $pubid){
		$query = "SELECT publisher_name FROM publisher WHERE publisherid = '$pubid'";//الاتعسلام بالاي دي لناشر
		$result = mysqli_query($conn, $query);//تخزين الاستعلام
		if(!$result){//اذا كان خطأ
			echo "Can't retrieve data " . mysqli_error($conn);//أطبع رساله خطأ
			exit;
		}
		  //mysqli_num_rows($result) ==> Return the number of rows in result set
		if(mysqli_num_rows($result) == 0){//اذا كانت مصفوفه الاستعلام تساوي صفر
			echo "Empty books ! Something wrong! check again";//اطبع رساله خطاء 
			exit;
		}

		$row = mysqli_fetch_assoc($result);// قراءة السجل من قاعدة البيانات ووضعه في مصفوفة حسب اسم العمود في قاعدة البيانات
		return $row['publisher_name'];
	}

	function getAll($conn){
		$query = "SELECT * from books ORDER BY book_isbn DESC";//الاستعلام عن الكتب مرتبه بواسطه الناشر
		$result = mysqli_query($conn, $query);//تخزين الاستعلام
		if(!$result){
			echo "Can't retrieve data " . mysqli_error($conn);
			exit;
		}
		return $result;
	}
?>