<?php
	if(!isset($_SESSION['admin']) && $_SESSION['admin'] != true){//اذا لم يكن للادمن سيشن اي جلسه مفتوحه
		$_SESSION['err_login'] = "Please Login First";//تظهر له رساله ارجو تسجيل الدخول
		header("Location: admin.php");//بعدها يتوجه لصفحه الادمن
	}
?>