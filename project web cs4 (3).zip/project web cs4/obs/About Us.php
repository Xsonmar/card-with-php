<?php
  session_start();
  $count = 0;
  // connecto database
  
  $title = "Home";
  require_once "./template/header.php";
  require_once "./functions/database_functions.php";
  $conn = db_connect();
  $row = select4LatestBook($conn);
?>
    <br><br>
  <div id="about-us">
        <h1>About Us</h1>
        <p>Welcome to our online bookstore! We are passionate about books and committed to bringing you the best titles across various genres. Our mission is to create a space where book lovers can find their next favorite read while enjoying a seamless shopping experience.</p>
        <p>Founded in <span id="foundingYear"></span>, we have been serving our customers with dedication and love for literature. We believe in the power of books to inspire, educate, and entertain. Thank you for visiting our store, and we hope you find something wonderful to read!</p>

        <!-- Collapsible Section -->
        <button class="collapsible">Read More About Us</button>
        <div class="content">
            <p>Our bookstore offers a wide range of books from various genres including fiction, non-fiction, self-help, and more. We strive to provide a diverse collection to cater to the varied interests of our readers.</p>
            <p>We are constantly updating our inventory with the latest releases and timeless classics. Our team is dedicated to ensuring that you have a pleasant shopping experience with us.</p>
        </div>
    </div>

    <script>
        // JavaScript to dynamically display the current year
        document.getElementById("foundingYear").innerHTML = new Date().getFullYear();

        // JavaScript for collapsible section
        var coll = document.getElementsByClassName("collapsible");
        for (var i = 0; i < coll.length; i++) {
            coll[i].addEventListener("click", function() {
                this.classList.toggle("active");
                var content = this.nextElementSibling;
                if (content.style.display === "block") {
                    content.style.display = "none";
                } else {
                    content.style.display = "block";
                }
            });
        }
    </script>
<?php
  if(isset($conn)) {mysqli_close($conn);}
  require_once "./template/footer.php";
?>
