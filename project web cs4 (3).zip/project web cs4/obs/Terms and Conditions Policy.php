<?php
  session_start();
 
  // connecto database
  
  $title = "Terms and Conditions Policy";
  require_once "./template/header.php";
  require_once "./functions/database_functions.php";
  $conn = db_connect();
 
?>

    <br><br><br>
       <div id="po">

    <h2>Privacy Policies</h2>
    <p>
        The privacy policy of “BookShelf” aims to protect users personal information,
         which includes name, location, and bank card information.
         The "BookShelf" site pledges to protect this information and not share it with third parties
    </p>
    <h2>Conditions Policy</h2>
    <p>
        It includes the conditions of use, such as intellectual property rights for the books and intellectual content on the site.
    </p>
  </div>

  <?php
  if(isset($conn)) {mysqli_close($conn);}
  require_once "./template/footer.php";
?>