<?php

//الاستعلام عن بيانات الادمن 
	$email = $_POST['inputEmail'];//بيانات الادمن الايميل او اسم المستخدم
	$pswd = $_POST['inputPasswd'];//بيانات الادمن من الباسوورد

	$conn = mysqli_connect("localhost", "root", "", "obs_db");//الاتصال بقاعده البيانات
	if(!$conn){//التحقق من الاتصال بقاعده البيانات
		echo "Cannot connecto to database " . mysqli_connect_error($conn);//ارساله رساله خطاء في الاتصال بقاعده البيانات
		exit;//خروج
	}

	$query = "SELECT username, password FROM admin";//في متغير استعلم عن اسم المستخدم و الباسوورد من جدول الادمن
	$result = mysqli_query($conn, $query);//نتيجه الاستعلام
	if(!$result){//التحقق ان كان الاستعلام فارغ
		echo "Empty!";//طباعه كلمه فارغ
		exit;//خروج
	}

	while ($row = mysqli_fetch_assoc($result)){//في شرط وايل تخزين النتيجه في متغير  لدخول الشرط
		if($email == $row['username'] && $pswd == $row['password']){//التحقق من البانات التي تم جلبها من قاعده البيانات
			echo "Welcome admin! Long time no see";//ان كان الاستعلام صحيح يطبع رساله ترحيبيه للادمن
			break;//توقف
		}
	}
?>