<?php
//جلسه الادمن
	session_start();
	session_destroy();//الخروج من الجلسه
	header("Location: index.php");//العوده لصفحه الكتب للمستخدم
?>