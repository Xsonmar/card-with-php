<?php
	session_start();//جلسه الادمن
	if(!isset($_POST['submit'])){//اذا كانت البيانات خاطئه او خاليه اظهر لي رساله
		echo "Something wrong! Check again!";//رساله الخطاء
		exit;//خروج
	}
	require_once "./functions/database_functions.php"; //ربط ملف بيانات الوظائف
	$conn = db_connect();//الاتصال بقاعده البيانات

	//جلب البيانات وتخزينها في متغيرات
	$name = trim($_POST['name']);
	$pass = trim($_POST['pass']);

	//التتحقق من وجود بيانات  في المتغير
	if($name == "" || $pass == ""){//اذا كانت بيانات خاليه
		echo "Name or Pass is empty!";//ارجع لي رساله خطاء 
		exit;//خروج
	}

	$name = mysqli_real_escape_string($conn, $name);//البيانات المدخله الخاليه من الاحرف او الارقام الخاصه
	$pass = mysqli_real_escape_string($conn, $pass);//البيانات المدخله الخاليه من الاحرف او الارقام الخاصه
	$pass = sha1($pass);//تشفير الرمز المدخل

	// get from db
	//البيانات الموجوده بقاعده البيانات
	$query = "SELECT `name`, `pass` from `admin` where `name` = '{$name}' and `pass` ='{$pass}'";
	$result = mysqli_query($conn, $query);
	if($result->num_rows <= 0){ //اذا كانت تساوي صفر اضهر لي رساله خطاء 
		$_SESSION['err_login'] = "Incorrect Username or Password";//رساله خطاء في ادخال البيانات
		header("Location: admin.php");//توجيه المستخدم لملف تسجيل دخول الادمن
		exit;//خروج
	}
	if(isset($conn)) {mysqli_close($conn);}//اغلق الجلسه السابقه
	$_SESSION['admin'] = true;//اذا كانت الجلسه للمستخدم الادمن
	header("Location: admin_book.php");//توجيه المستخدم لكتب الادمن
?>