<?php
  session_start();
 
  // connecto database
  
  $title = "customer service";
  require_once "./template/header.php";
  require_once "./functions/database_functions.php";
  $conn = db_connect();
?>
    <br><br>
    <div id="customer-service">
        <h1>Customer Service</h1>
        <p>We're here to help you. Find answers to your questions below or contact us directly.</p>

        <!-- FAQ Section -->
        <h2>Frequently Asked Questions</h2>
        <button class="collapsible">What is your return policy?</button>
        <div class="content">
            <p>We accept returns within 30 days of purchase. The book must be in its original condition. Please contact us for return instructions.</p>
        </div>

        <button class="collapsible">How can I track my order?</button>
        <div class="content">
            <p>Once your order is shipped, you will receive an email with tracking information. You can also track your order from your account on our website.</p>
        </div>

        <button class="collapsible">Do you ship internationally?</button>
        <div class="content">
            <p>Yes, we do offer international shipping. Shipping costs and delivery times vary by location.</p>
        </div>


    <script>
        // JavaScript for collapsible section
        var coll = document.getElementsByClassName("collapsible");
        for (var i = 0; i < coll.length; i++) {
            coll[i].addEventListener("click", function() {
                this.classList.toggle("active");
                var content = this.nextElementSibling;
                if (content.style.display === "block") {
                    content.style.display = "none";
                } else {
                    content.style.display = "block";
                }
            });
        }
    </script>
<?php
  if(isset($conn)) {mysqli_close($conn);}
  require_once "./template/footer.php";
?>
