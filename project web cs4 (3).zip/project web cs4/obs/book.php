<?php
//في هذي الصفحه كامله هي الي تضهر معلومات الكتاب لحاله 
  session_start(); //بدايه السيشن
  $book_isbn = $_GET['bookisbn'];
  // connecto database
  require_once "./functions/database_functions.php";
  $conn = db_connect();

  $query = "SELECT * FROM books WHERE book_isbn = '$book_isbn'";//تحديد الاسبن للكتاب 
  $result = mysqli_query($conn, $query);//استعلام النتيجه
  if(!$result){//اذا كان الاستعلام خطاء
    echo "Can't retrieve data " . mysqli_error($conn);//بتظهر رساله الخطاء
    exit;//خروج
  }

  $row = mysqli_fetch_assoc($result);//اظهر النتيجه في متغير 
  if(!$row){//اذا ماكان في المتغير نتيجه
    echo "Empty book";//بيطبع لي ان معلومات الكتاب فاضيه
    exit;
  }

  $title = $row['book_title']; //هذا الاستعلام من الداتا بيز يأخذ عنوان الكتاب المحدد ويضعه في التيتل لصفحه
  require "./template/header.php";//ربط الصفحه بملف الهيدر
?>
      <!--  row of columns -->
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="books.php" class="text-decoration-none text-muted fw-light">PublBooksishers</a></li>
                <!--$rowاظهار العنوان الموجود  في البيانات التي تم جلبها بواسطه المتغير -->

          <li class="breadcrumb-item active" aria-current="page"><?php echo $row['book_title']; ?></li>
        </ol>
      </nav>
      <!--$rowاظهار الصوره الموجوده  في البيانات التي تم جلبها بواسطه المتغير -->
      <div class="row">
        <div class="col-md-3 text-center book-item">
          <div class="img-holder overflow-hidden">
          <img class="img-top" src="./bootstrap/img/<?php echo $row['book_image']; ?>">
          </div>
        </div>
        <div class="col-md-9">
          <div class="card rounded-0 shadow">
            <div class="card-body">
              <div class="container-fluid">
                <h4><?= $row['book_title'] ?></h4>
                <hr>
                      <!--$rowاظهار وصف الكتاب الموجوده  في البيانات التي تم جلبها بواسطه المتغير -->

                  <p><?php echo $row['book_descr']; ?></p>
                  <h4>Details</h4>
                  <table class="table">
                    <!--شرط اذا كانت البيانات التي تم جلبها  صحيحه-->
                    <?php foreach($row as $key => $value){
                      if($key == "book_descr" || $key == "book_image" || $key == "publisherid" || $key == "book_title"){
                        continue;//اكمل 
                      }
                      //قم بطباعتها في السطر البرمجي التالي 
                      switch($key){
                        case "book_isbn":
                          $key = "ISBN";
                          break;
                        case "book_title":
                          $key = "Title";
                          break;
                        case "book_author":
                          $key = "Author";
                          break;
                        case "book_price":
                          $key = "Price";
                          break;
                      }
                    ?>
                    <tr>
                      <td><?php echo $key; ?></td>
                      <td><?php echo $value; ?></td>
                    </tr>
                    <?php 
                      } 
                      if(isset($conn)) {mysqli_close($conn); }//اغلق قاعده البيانات السابقه
                    ?>
                  </table>
                  <form method="post" action="cart.php"><!--فورم لارسال البيانات الى السله-->
                    <input type="hidden" name="bookisbn" value="<?php echo $book_isbn;?>">
                    <div class="text-center"> 
                      <input type="submit" value="Purchase / Add to cart" name="cart" class="btn btn-primary rounded-0">
                    </div>
                  </form>
              </div>
            </div>
          </div>
       	</div>
      </div>
<?php
  require "./template/footer.php";//ربط ملف الفوتر في الصفحه
?>