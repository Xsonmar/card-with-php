<?php
	session_start();//بدايه الجلسه

	session_unset();//حذف البيانات الموجوده بالجلسه
?>