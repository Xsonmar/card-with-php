<?php
//جلب بيانات الكتاب اسبن
	$book_isbn = $_GET['bookisbn'];

	require_once "./functions/database_functions.php";
	$conn = db_connect(); //الاتصال بقاعده البيانات

	$query = "DELETE FROM books WHERE book_isbn = '$book_isbn'"; // الاستعلام التالي لحذف الكتاب من قاعده البانات
	$result = mysqli_query($conn, $query); //نتيجه الحذف
	if(!$result){ //ان لم تنجح عمليه الحذف 
		echo "delete data unsuccessfully " . mysqli_error($conn); //اظهار رساله لم تنجح عمليه الحذف مع رساله خطاء
		exit; //خروج من الاستعلام
	}
	header("Location: admin_book.php");
?>